# ⚖️ Sistema de Preinscripción — Postgrado en Derecho USM

Sistema web completo para la gestión y registro de preinscripciones del Postgrado en Derecho de la **Universidad Santa María (USM)**.

---

## 🚀 Requisitos Previos

- [Node.js](https://nodejs.org/) (versión 18 o superior recomendada)
- Conexión a Internet (para el envío de correos SMTP de Gmail)

---

## 🛠️ Instalación y Puesta en Marcha

1. **Clonar o descargar el proyecto:**
   ```bash
   git clone <URL_DEL_REPOSITORIO>
   cd "usm postgrado"
   ```

2. **Instalar dependencias de Node.js:**
   ```bash
   npm install
   ```

3. **Configurar variables de entorno:**
   Copia el archivo `.env.example` y nómbralo `.env`:
   ```bash
   cp .env.example .env
   ```
   Edita `.env` con tus credenciales de Gmail (requiere [Contraseña de Aplicación de Google](https://myaccount.google.com/apppasswords)):
   ```env
   PORT=3000
   BASE_URL=http://localhost:3000
   ADMIN_EMAIL=tu_correo@gmail.com
   SMTP_USER=tu_correo@gmail.com
   SMTP_PASS=tu_clave_de_aplicacion
   ```

4. **Iniciar el sistema:**
   - **En Windows (un clic):** Haz doble clic en `iniciar_sistema.bat`.
   - **Por consola:**
     ```bash
     npm start
     ```
   - **Modo Público (acceso por Internet sin abrir puertos):**
     Haz doble clic en `iniciar_publico.bat` o ejecuta:
     ```bash
     node tunnel.js
     ```

5. **Abrir en el navegador:**
   - **Página de Preinscripción:** [http://localhost:3000](http://localhost:3000)
   - **Panel Administrativo:** [http://localhost:3000/admin.html](http://localhost:3000/admin.html)
   - **Consulta de Estatus:** [http://localhost:3000/consulta.html](http://localhost:3000/consulta.html)

---

## ✨ Características Principales

- 🎓 **10 Programas Académicos con Pensum Oficial:**
  - Especializaciones: Penal, Mercantil, Laboral, Procesal, Tributario, Administrativo.
  - Maestrías: Penal, Mercantil, Constitucional.
  - Doctorado en Derecho.
  - Modal interactivo con detalle de materias por semestre, códigos, U.C. y horas académicas.
- 📅 **Validación estricta de fecha de nacimiento** (edad entre 20 y 95 años).
- 📧 **Envío directo de recaudos por Gmail:** El aspirante recibe el código oficial, lista de requisitos autenticados y enlaces a [usm.edu.ve](https://usm.edu.ve).
- 🗄️ **Base de datos SQLite embebida (`sql.js`):** Funciona sin configuraciones complejas de motores externos.
- 📱 **100% Responsivo:** Adaptado para teléfonos inteligentes, tablets y computadoras.
- 🔧 **Panel de Control Administrativo:**
  - Búsqueda y filtrado por estado (`pendiente`, `revisada`, `aceptada`, `rechazada`).
  - Botón de reenvío de correo con 1 clic.
  - Prueba rápida de correo SMTP.
  - Código QR para abrir la página en el celular desde la misma red Wi-Fi.

---

## 📁 Estructura del Código

```
├── server.js              # Servidor Express principal y API REST con autenticación
├── database.js            # Motor SQLite (sql.js) y consultas
├── email.js               # Generador HTML y transporte SMTP
├── tunnel.js              # Túnel público con Enlace Oficial USM
├── iniciar_sistema.bat    # Lanzador en modo red local (Wi-Fi)
├── iniciar_publico.bat    # Lanzador con acceso mundial por Internet (Enlace Oficial USM)
├── .env.example           # Plantilla de configuración
├── private/
│   └── admin.html         # Panel administrativo protegido (con usuario y contraseña)
├── public/
│   ├── index.html         # Formulario con modal de pensum y confirmación
│   ├── login.html         # Inicio de sesión oficial para el administrador
│   ├── consulta.html      # Búsqueda de estatus por código USM-DER-*
│   ├── css/styles.css     # Estilos e identidad visual USM
│   └── js/
│       ├── app.js         # Lógica del formulario y pensum
│       └── admin.js       # Lógica y aprobación de solicitudes del panel admin
```

---

## 👨‍💻 Para Colaboradores

- Todo cambio en el diseño frontend se realiza en `public/index.html`, `public/css/styles.css` y `public/js/app.js`.
- Nuevos endpoints o lógica de negocio se agregan en `server.js` y `database.js`.
- No subir el archivo `.env` al repositorio público para proteger las contraseñas.
