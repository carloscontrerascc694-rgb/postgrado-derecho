// ============================================================
// tunnel.js - Túnel con Enlace Oficial USM para Acceso Público
// Sistema de Preinscripción - Postgrado en Derecho USM
// ============================================================

process.on('uncaughtException', (err) => {
    console.warn('⚠️ [Túnel] Excepción capturada (servidor continúa activo):', err.message);
});

process.on('unhandledRejection', (reason) => {
    console.warn('⚠️ [Túnel] Rechazo capturado (servidor continúa activo):', reason && reason.message ? reason.message : reason);
});

// Mantiene el proceso activo indefinidamente
setInterval(() => {}, 60000);

require('dotenv').config();
const path = require('path');
const fs = require('fs');
const os = require('os');
const localtunnel = require('localtunnel');

const { app } = require('./server');
const { inicializarDB } = require('./database');

const PORT = process.env.PORT || 3000;

// Subdominios oficiales prioritarios para la USM
const SUBDOMINIOS_USM = [
    'usm-postgrado-derecho-2026',
    'postgrado-derecho-usm-2026',
    'usm-derecho-postgrado',
    'preinscripcion-usm-derecho'
];

function getNetworkIp() {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
            if (iface.family === 'IPv4' && !iface.internal) return iface.address;
        }
    }
    return 'localhost';
}

let activeTunnel = null;
let isReconnecting = false;
let intentoSubdominio = 0;
let urlOficialUsm = 'https://usm-postgrado-derecho-2026.loca.lt';
let publicIp = '190.94.212.200';

async function iniciarConTunel() {
    await inicializarDB();

    app.locals.urlFacil = urlOficialUsm;
    app.locals.publicIp = publicIp;

    // Obtener IP pública real en segundo plano
    fetch('https://api.ipify.org').then(r => r.text()).then(ip => {
        if (ip && ip.trim()) {
            publicIp = ip.trim();
            app.locals.publicIp = publicIp;
        }
    }).catch(() => {});

    // 1. Iniciar servidor local
    await new Promise((resolve) => {
        const server = app.listen(PORT, '0.0.0.0', () => {
            console.log('');
            console.log('  ✅ Servidor local activo en http://localhost:' + PORT);
            resolve();
        });
        server.on('error', (err) => {
            if (err.code === 'EADDRINUSE') {
                console.error(`⚠️ Puerto ${PORT} ocupado. Reintentando en 3s...`);
            }
            setTimeout(() => {
                iniciarConTunel().catch(() => {});
            }, 3000);
        });
    });

    // 2. Conectar al Túnel Oficial USM
    await conectarTunelUsm();
}

async function conectarTunelUsm() {
    if (isReconnecting) return;
    isReconnecting = true;

    if (activeTunnel) {
        try {
            activeTunnel.removeAllListeners();
            activeTunnel.close();
        } catch (e) {}
        activeTunnel = null;
    }

    const subdominioDeseado = SUBDOMINIOS_USM[intentoSubdominio % SUBDOMINIOS_USM.length];

    try {
        const tunnel = await localtunnel({
            port: parseInt(PORT, 10),
            subdomain: subdominioDeseado
        });

        // Verificar que sea un nombre oficial referente a la USM
        if (!tunnel.url.toLowerCase().includes('usm') && !tunnel.url.toLowerCase().includes('derecho')) {
            console.log(`⚠️ Servidor asignó temporalmente (${tunnel.url}). Reintentando con subdominio USM en 4s...`);
            try { tunnel.close(); } catch (e) {}
            intentoSubdominio++;
            isReconnecting = false;
            setTimeout(conectarTunelUsm, 4000);
            return;
        }

        activeTunnel = tunnel;
        isReconnecting = false;

        urlOficialUsm = tunnel.url;
        app.locals.urlFacil = urlOficialUsm;

        guardarYMostrarBanner(urlOficialUsm, getNetworkIp(), publicIp);

        tunnel.on('close', () => {
            console.log('🔄 Túnel desconectado por inactividad. Reconectando en 4s...');
            setTimeout(conectarTunelUsm, 4000);
        });

        tunnel.on('error', (err) => {
            console.warn('⚠️ Aviso de conexión:', err ? err.message : 'Error');
            intentoSubdominio++;
            setTimeout(conectarTunelUsm, 4000);
        });

    } catch (err) {
        console.warn(`⚠️ Error al vincular "${subdominioDeseado}". Probando siguiente nombre en 4s...`);
        intentoSubdominio++;
        isReconnecting = false;
        setTimeout(conectarTunelUsm, 4000);
    }
}

function guardarYMostrarBanner(urlUsm, localIp, publicIp) {
    const contenidoTxt = `===========================================================
ENLACE OFICIAL DE ACCESO PÚBLICO - POSTGRADO EN DERECHO USM
===========================================================

1. ENLACE OFICIAL USM (Para compartir con todos los aspirantes):
   ${urlUsm}
   (Si te pide "Tunnel Password", coloca tu IP: ${publicIp})

2. PANEL ADMINISTRATIVO PRIVADO (Solo para el Administrador):
   ${urlUsm}/admin.html
   Usuario: ${process.env.ADMIN_USER || 'admin'}
   Clave:   ${process.env.ADMIN_PASS || 'usm2026'}

3. ACCESO EN LA MISMA RED WI-FI:
   http://${localIp}:${PORT}

4. ACCESO EN ESTA COMPUTADORA:
   http://localhost:${PORT}
`;
    fs.writeFileSync(path.join(__dirname, 'ENLACE_PUBLICO.txt'), contenidoTxt);

    console.log('');
    console.log('  ╔══════════════════════════════════════════════════════════════════════════╗');
    console.log('  ║                                                                          ║');
    console.log('  ║   🎓  UNIVERSIDAD SANTA MARÍA - FACULTAD DE DERECHO                      ║');
    console.log('  ║   ⭐  ENLACE OFICIAL USM DE ACCESO PÚBLICO                               ║');
    console.log('  ║                                                                          ║');
    console.log('  ╠══════════════════════════════════════════════════════════════════════════╣');
    console.log('  ║                                                                          ║');
    console.log('  ║   🔗  ENLACE OFICIAL PARA ASPIRANTES:                                    ║');
    console.log(`  ║       ${urlUsm.padEnd(67)}║`);
    console.log('  ║                                                                          ║');
    console.log('  ║   🔑  Contraseña del túnel (Tunnel Password al entrar):                  ║');
    console.log(`  ║       ${publicIp.padEnd(67)}║`);
    console.log('  ║                                                                          ║');
    console.log('  ║   🔒  PANEL ADMINISTRATIVO PRIVADO:                                      ║');
    console.log(`  ║       ${(urlUsm + '/admin.html').padEnd(67)}║`);
    console.log(`  ║       Usuario: ${process.env.ADMIN_USER || 'admin'}  |  Clave: ${process.env.ADMIN_PASS || 'usm2026'}`.padEnd(73) + '║');
    console.log('  ║                                                                          ║');
    console.log('  ║   📱  En la misma red Wi-Fi:                                             ║');
    console.log(`  ║       http://${localIp}:${PORT}`.padEnd(71) + '║');
    console.log('  ║                                                                          ║');
    console.log('  ╚══════════════════════════════════════════════════════════════════════════╝');
    console.log('');
    console.log(`  👉 Comparte este enlace con los aspirantes por WhatsApp o correo:`);
    console.log(`     🌐 ${urlUsm}`);
    console.log(`     (Si pide Tunnel Password la primera vez, solo colocas: ${publicIp})`);
    console.log('');
    console.log('  📁 Se guardó la información en: ENLACE_PUBLICO.txt');
    console.log('');
}

iniciarConTunel().catch(err => {
    console.error('❌ Error no crítico al iniciar, reintentando en 5s:', err.message);
    setTimeout(iniciarConTunel, 5000);
});
